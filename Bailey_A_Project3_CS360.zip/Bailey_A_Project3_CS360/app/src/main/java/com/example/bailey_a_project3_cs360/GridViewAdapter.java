package com.example.bailey_a_project3_cs360;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.List;

public class GridViewAdapter extends BaseAdapter {
    private Context context;
    private List<Item> itemList;

    public GridViewAdapter(Context context, List<Item> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @Override
    public int getCount() {
        return itemList.size();
    }

    @Override
    public Object getItem(int position) {
        return itemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        // Check if the convertView is null, indicating it hasn't been inflated yet
        if (convertView == null) {
            // Inflate the grid item layout if convertView is null
            convertView = LayoutInflater.from(context).inflate(R.layout.grid_item_layout, parent, false);

            // Create a ViewHolder object and store references to the views
            viewHolder = new ViewHolder();
            viewHolder.textViewDate = convertView.findViewById(R.id.textViewDate);
            viewHolder.textViewWeight = convertView.findViewById(R.id.textViewWeight);

            // Set the ViewHolder as a tag for the convertView
            convertView.setTag(viewHolder);
        } else {
            // If convertView is not null, get the ViewHolder from its tag
            viewHolder = (ViewHolder) convertView.getTag();
        }

        // Get the Item object at the current position
        Item item = itemList.get(position);

        // Bind data to views in the grid item layout using the ViewHolder
        viewHolder.textViewDate.setText(item.getDate());
        viewHolder.textViewWeight.setText(String.valueOf(item.getWeight()));

        return convertView;
    }

    // ViewHolder pattern to improve ListView performance by caching views
    private static class ViewHolder {
        TextView textViewDate;
        TextView textViewWeight;
    }
}
