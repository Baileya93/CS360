package com.example.bailey_a_project3_cs360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "WeightLossTracker.db";
    private static final int DATABASE_VERSION = 1;

    // Table names
    private static final String TABLE_USER_ACCOUNTS = "user_accounts";
    private static final String TABLE_DAILY_WEIGHT = "daily_weight";

    // User Accounts Table Columns
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_EMAIL = "email";

    // Daily Weight Table Columns
    private static final String COLUMN_WEIGHT_ID = "weight_id";
    private static final String COLUMN_USER_ID_FK = "user_id_fk";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";

    // SQL query to create User Accounts table
    private static final String CREATE_TABLE_USER_ACCOUNTS = "CREATE TABLE " +
            TABLE_USER_ACCOUNTS + "(" +
            COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_USERNAME + " TEXT," +
            COLUMN_PASSWORD + " TEXT," +
            COLUMN_EMAIL + " TEXT" +
            ")";

    // SQL query to create Daily Weight table
    private static final String CREATE_TABLE_DAILY_WEIGHT = "CREATE TABLE " +
            TABLE_DAILY_WEIGHT + "(" +
            COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_USER_ID_FK + " INTEGER," +
            COLUMN_DATE + " TEXT," +
            COLUMN_WEIGHT + " REAL," +
            "FOREIGN KEY(" + COLUMN_USER_ID_FK + ") REFERENCES " + TABLE_USER_ACCOUNTS + "(" + COLUMN_USER_ID + ")" +
            ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Enable foreign key constraints
        db.execSQL("PRAGMA foreign_keys=ON;");

        // Create tables
        db.execSQL(CREATE_TABLE_USER_ACCOUNTS);
        db.execSQL(CREATE_TABLE_DAILY_WEIGHT);
    }

    public long addWeightEntry(long userId, String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID_FK, userId);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);
        long newRowId = db.insert(TABLE_DAILY_WEIGHT, null, values);
        db.close();
        return newRowId;
    }

    public int deleteWeightEntry(long entryId) {
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = COLUMN_WEIGHT_ID + " = ?";
        String[] selectionArgs = { String.valueOf(entryId) };
        int count = db.delete(
                TABLE_DAILY_WEIGHT,
                selection,
                selectionArgs
        );
        db.close();
        return count;
    }

    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            // Query the database to retrieve all items
            cursor = db.query(TABLE_DAILY_WEIGHT, null, null, null, null, null, null);

            // Check if the cursor is not null and contains at least one row
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    // Initialize variables to hold column indices
                    int itemIdIndex = cursor.getColumnIndex(COLUMN_WEIGHT_ID);
                    int userIdIndex = cursor.getColumnIndex(COLUMN_USER_ID_FK);
                    int dateIndex = cursor.getColumnIndex(COLUMN_DATE);
                    int weightIndex = cursor.getColumnIndex(COLUMN_WEIGHT);

                    // Check if column indices are valid (not -1)
                    if (itemIdIndex != -1 && userIdIndex != -1 && dateIndex != -1 && weightIndex != -1) {
                        // Extract data from the cursor and create Item objects
                        long itemId = cursor.getLong(itemIdIndex);
                        long userId = cursor.getLong(userIdIndex);
                        String date = cursor.getString(dateIndex);
                        double weight = cursor.getDouble(weightIndex);

                        // Create an Item object and add it to the itemList
                        Item item = new Item(itemId, userId, date, weight);
                        itemList.add(item);
                    } else {
                        // Log a warning if any column index is -1
                        Log.w("DatabaseHelper", "Column index not found in cursor");
                    }
                } while (cursor.moveToNext());
            }
        } finally {
            // Close the cursor to release its resources
            if (cursor != null) {
                cursor.close();
            }
        }

        // Return the populated itemList
        return itemList;
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_ACCOUNTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DAILY_WEIGHT);

        // Create tables again
        onCreate(db);
    }

    // Placeholder class for Item
    public static class Item {
        private long itemId;
        private long userId;
        private String date;
        private double weight;

        public Item(long itemId, long userId, String date, double weight) {
            this.itemId = itemId;
            this.userId = userId;
            this.date = date;
            this.weight = weight;
        }

        // Getter methods for Item fields
        public long getItemId() {
            return itemId;
        }

        public long getUserId() {
            return userId;
        }

        public String getDate() {
            return date;
        }

        public double getWeight() {
            return weight;
        }
    }
}
