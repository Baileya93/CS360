package com.example.bailey_a_project3_cs360;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.GridView;
import java.util.ArrayList;
import java.util.List;

import com.example.bailey_a_project3_cs360.DatabaseHelper;
import com.example.bailey_a_project3_cs360.Item;
import com.example.bailey_a_project3_cs360.GridViewAdapter;

public class GridActivity extends AppCompatActivity {

    private GridView gridView;
    private DatabaseHelper databaseHelper;
    private List<Item> itemList;
    private GridViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        // Initialize views, database helper, item list, and adapter
        gridView = findViewById(R.id.gridView);
        databaseHelper = new DatabaseHelper(this);
        itemList = new ArrayList<>();
        adapter = new GridViewAdapter(this, itemList);
        gridView.setAdapter(adapter);

        // Fetch data from the database and populate the grid view
        fetchItemsFromDatabase();
    }

    // Method to fetch items from the database and update the grid view
    private void fetchItemsFromDatabase() {
        try {
            // Retrieve items from the database using DatabaseHelper methods
            List<Item> newItems = databaseHelper.getAllItems();

            // Clear the existing itemList and add the new items
            itemList.clear();
            itemList.addAll(newItems);

            // Notify adapter of data set change
            adapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the exception (e.g., show error message to the user)
        }
    }
}
